
# Fisier nou model.ts:
>> snippet tasks-list-js.txt
>> simulam un serviciu de date

    export class Project {
        name;
        tasks;
        constructor() {
            this.name = "Website Development";
            this.tasks = [new TaskItem(1, "Task ONE", 'Closed', 'James Hansen', '03/11/2051'),
            new TaskItem(2, "Task TWO", 'Working', 'Louise Meyer', '23/11/2051'),
            new TaskItem(3, "Task THREE", 'Rejected', 'Todd Fields', '	30/11/2051'),
            new TaskItem(4, "Task FOUR", 'New', 'Louise Meyer', '05/12/2051')]
        }
    }
    export class TaskItem {
        constructor(
            public id: number, 
            public subject, 
            public status, 
            public asignee, 
            public deadline) { 

        }
    }


# Cream un template nou:
>> app/task.component.html    

>> copiem codul din index.html aici:
>> lasam doar un singur <tr> si modificam <h1>

<main class="col-sm-7 offset-sm-2 pt-3">
    <h1 class="bg-primary p-3 text-info">Project: {{ getProjectName() }}</h1>

    <h2>Tasks</h2>
    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Subject</th>
                    <th>Status</th>
                    <th>Asignee</th>
                    <th>Deadline</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>Task ONE</td>
                    <td>Closed</td>
                    <td>James Hansen</td>
                    <td>03/11/2051</td>
                </tr>
            </tbody>
        </table>
    </div>
</main>



# Cream o componenta noua:
>> task.component.ts:

    import { Component } from "@angular/core";
    import { Project } from "./model";
    @Component({
        selector: "task-list",
        templateUrl: "app/task.component.html"
    })
    export class AppComponent {
        project = new Project();
        getProjectName() {
            return this.project.name;
        }
    }



# Modulul Root: Avem nevoie acum de un modul Angular:
>> app.module.ts:

    import { NgModule } from "@angular/core";
    import { BrowserModule } from "@angular/platform-browser";
    import { FormsModule } from "@angular/forms";

    import { ProjectComponent } from "./task.component";

    @NgModule({
        imports: [BrowserModule, FormsModule],
        declarations: [ProjectComponent],
        bootstrap: [ProjectComponent]
    })
    export class AppModule { }



# Fisierul Bootstrap: 
>> main.ts:

import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app.module';

platformBrowserDynamic().bootstrapModule(AppModule);



# Modificam index.html:

    <script src="systemjs.config.js"></script>
    <script>
      System.import('app').catch(function(err){ console.error(err); });
    </script>

<body>
    <task-list>Incarcare modul...</task-list>
</body>    



# Adaugam systemjs.config.js in root 
>> vezi snippet systemjs.config.js.txt 



# Acum aplicatia ar trebui sa functioneze in browser 

>> daca nu este deja in modul watch:
    > npm start 





