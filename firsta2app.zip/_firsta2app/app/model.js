"use strict";
var Project = (function () {
    function Project() {
        this.name = "Website Development";
        this.tasks = [new TaskItem(1, "Task ONE", 'Closed', 'James Hansen', '03/11/2051'),
            new TaskItem(2, "Task TWO", 'Working', 'Louise Meyer', '23/11/2051'),
            new TaskItem(3, "Task THREE", 'Rejected', 'Todd Fields', '	30/11/2051'),
            new TaskItem(4, "Task FOUR", 'New', 'Louise Meyer', '05/12/2051')];
    }
    return Project;
}());
exports.Project = Project;
var TaskItem = (function () {
    function TaskItem(id, subject, status, asignee, deadline) {
        this.id = id;
        this.subject = subject;
        this.status = status;
        this.asignee = asignee;
        this.deadline = deadline;
    }
    return TaskItem;
}());
exports.TaskItem = TaskItem;
//# sourceMappingURL=model.js.map