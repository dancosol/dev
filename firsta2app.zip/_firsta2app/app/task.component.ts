import { Component } from "@angular/core";
import { Project } from "./model";
@Component({
    selector: "task-list",
    templateUrl: "app/task.component.html"
})
export class ProjectComponent {
    project = new Project();
    getProjectName() {
        return this.project.name;
    }
}